function f = fact2(n)
% factorial using for loop

f = 1;
for i=1:n
  f = i*f;
end;
