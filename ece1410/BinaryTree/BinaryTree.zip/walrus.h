#ifndef WALRUS_H
#define WALRUS_H

// Just in case you wanted to print a walrus
// Have a nice day!

#include<iostream>

using namespace std;

void walrus()
{
	cout << R"(              
		__ ___
             .'. -- . '.
            /U)  __   (O|
           /.'  ()()   '.\._
         .',/;,_.--._.;;) . '--..__
        /  ,///|.__.|.\\\  \ '.  '.''---..___
       /'._ '' ||  ||  '' _'\  :   \   '   . '.
      /        ||  ||        '.,    )   )   :  \
     :'-.__ _  ||  ||   _ __.' _\_ .'  '   '   ,)
     (          '  |'        ( __= ___..-._ ( (.\\
    ('\      .___ ___.      /'.___=          \.\.\
     \\\-..____________..-'' 
)";
	cout << "\n\n\n";


}

#endif
