#include "CryptoAES.hpp"
#include <iostream>
#include <ctime>
#include <mcrypt>

CryptoCaesar::CryptoAES(std::function<void(const uint8_t *data, uint32_t len)> encryptCallback,
                           std::function<void(const uint8_t *data, uint32_t len)> decryptCallback)
: Crypto(encryptCallback, decryptCallback)
{
}

void CryptoAES::genKeys()
{
	// Do some stuff to get a random number and shift the stuff
	// Generate a random array/vector key. Size?
	std::srand(std::time(NULL));
	
	for (int i = 0; i < keyLen; i++)
	{
	    key[i] = (std::rand() % 256);
	   
	}
	for (i = 0; i < IVLen; i++)
	{
	    IV[i] = (std::rand() % 256);
	   
	}
}

bool CryptoAES::getKeys(uint8_t ** pubKey, uint32_t & pubLen, uint8_t ** 
priKey, uint32_t & priLen)
{
	if (!key || !buffLen)
	{
		std::cout << "No keys were generated!" << std::endl;
		return false;
	}
	else 
	{
	      
		*priKey = key;			//bad  ?
		priLen = buffLen;
	}
	
	// set length!!!
	return true;
}

void CryptoAES::setKeys(const uint8_t * pubKey, uint32_t pubLen, const uint8_t * priKey, uint32_t priLen)
{
	key = (uint8_t *) pubKey;
	length = pubLen;
}

void CryptoAES::destroyKeys()
{
	key = NULL;
	buffLen = 0;
}

bool CryptoAES::encrypt(const uint8_t * data, uint32_t len)
{
	if (key == NULL)
	{
		std::cout << "No key has been initialized" << std::endl;
		return false;
	}
	//memcpy (buff, data, len);		// copy data to buffer

	// get random number
	// shift numbers + rand % len;
	
	
	MCRYPT td = mcrypt_module_open("rijndael-128", NULL, "cbc", NULL);
	uint32_t blockSize = mcrypt_enc_get_block_size(td);
	if(len % blockSize != 0 )
	{
	  std::cout << "Incompatible block size" << std::endl;
	  return false;			// ?
	  
	}
	mcrypt_generic_init(td, key, keyLen, IV);
	totalEncrypted = 0;
	uint32_t i = 0; 		// local counting variable
	while (totalEncrypted < len)
	{
	  // read 16 bytes to buffer at a time and encrypt
	  if (len => buffLen + totalEncrypted)
	  {
	      for (i = 0; i < buffLen && totalEncrypted < len; i++, totalEncrypted++)	
	      {
		  buff[i] = data[totalEncrypted + i];		// const issue????
	      }
	      if (i < buffLen)
	      {
		std::fill(buff + i, buffLen, 0);	// pad the rest of the block with 0's. Is this necessary?
	      }
	      mcrypt_generic(td, buff, buffLen);
	      m_encryptCallback(buff, buffLen);		// write 16 bytes, padded?
	      //totalEncrypted += 16;
	  } 
	  else
	  {
	     for (i = 0; totali < 16; i++, totalEncrypted++)
	      {
		  buff[i] = data[totalEncrypted + i];		// const issue????
	      }
	      mcrypt_generic(td, buff, buffLen);
	      m_encryptCallback(buff, buffLen);		// write 16 bytes, padded?
	  }
	  
	}
	
	mcrypt_generic(td, NULL, 0);		// flush buffers
	mcrypt_generic_deinit (td);
	mcrypt_module_close(td);
	
	
	return true;
}

bool CryptoAES::decrypt(const uint8_t * data, uint32_t len)
{
	if (key == NULL || !len)
	{
		std::cout << "No key has been initialized" << std::endl;
		return false;
	}
	memcpy (buff, data, len);		// copy data to buffer
	
	MCRYPT td = mcrypt_module_open("rijndael-128", NULL, "cbc", NULL);
	int blocksize = mcrypt_enc_get_block_size(td);
	if( buffLen % blocksize != 0 )
	{
	  std::cout << "Incompatible block size" << std::endl;
	  return false;
	  
	}
	
	mcrypt_generic_init(td, key, keyLen, IV);
	to
	while (totalDencrypted > 0)
	{
	  // read 16 bytes to buff
	  for ( int i = 0; i < 16; i++, totalDecrypted--)
	  {
	      buff[i] = data[totalDecrypted + i];		// const issue????
	  }
	  mdecrypt_generic(td, buff, buffLen);
	  m_decryptCallback(buff, buffLen);		// write 16 bytes, padded?
	  //totalEncrypted += 16;
	}
	
	
	mdecrypt_generic(td, NULL, 0);		// flush buffers. Is this needed?
	mcrypt_generic_deinit (td);
	mcrypt_module_close(td);
	//m_decryptCallback(buff, len);
	return true;
}
